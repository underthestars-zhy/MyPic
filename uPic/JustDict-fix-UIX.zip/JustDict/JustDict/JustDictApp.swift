//
//  JustDictApp.swift
//  JustDict
//
//  Created by 朱浩宇 on 2021/7/21.
//

import SwiftUI

@main
struct JustDictApp: App {
    let persistenceController = PersistenceController.shared
    

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
