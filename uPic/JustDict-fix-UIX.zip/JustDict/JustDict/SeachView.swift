//
//  SeachView.swift
//  SeachView
//
//  Created by 朱浩宇 on 2021/7/25.
//

import SwiftUI
import SwiftUIX

struct SeachView: View {
    @Binding var searchBarHeight: CGFloat
    @Binding var isSearching: Bool
    @Binding var editQuickBar: Bool
    @Binding var searchText: String
    
    @ObservedObject var keyboardHeightHelper = KeyboardHeightHelper.share
    @ObservedObject var dataManager = DataManager.shared
    
    @GestureState private var dragState = DragState.insactive
    
    let offsetRight: CGFloat = Screen.main.width - 33 * 2 + 12
    
    var body: some View {
        VStack {
            ZStack() {
//                DynamicSearchView()
//                    .padding(.top, 71 + 33 + searchBarHeight)
//                    .modifier(DynamicSearchViewModifier(editQuickBar: $editQuickBar, isSearching: $isSearching))
//                    .offset(x: offsetRight, y: 0)
                
                DynamicSearchView(isSearching: $isSearching, searchText: $searchText, setId: dataManager.allDataSets.first?.uuid ?? UUID())
                    .padding(.top, 71 + 33 + searchBarHeight)
                    .modifier(DynamicSearchViewModifier(editQuickBar: $editQuickBar, isSearching: $isSearching))
                    .offset(x: isSearching ? dragState.translation.width : 0, y: 0)
                    .gesture(LongPressGesture(minimumDuration: 0.01)
                                .sequenced(before: DragGesture())
                                .updating($dragState, body: { value, state, translation in
                        switch value {
                        case .first(true): state = .pressing
                        case .second(true, let drage): state = .draggging(translation: drage?.translation ?? .zero)
                        default: break
                        }
                    }), including: .all)
                
//                DynamicSearchView()
//                    .padding(.top, 71 + 33 + searchBarHeight)
//                    .modifier(DynamicSearchViewModifier(editQuickBar: $editQuickBar, isSearching: $isSearching))
//                    .offset(x: -offsetRight, y: 0)
                
            }
            
            Spacer()
        }
    }
    
    private func calculateHeight(_ binding: Binding<CGFloat>) -> some View {
        GeometryReader { geometry -> Color in
            DispatchQueue.main.async {
                binding.wrappedValue = geometry.frame(in: .global).height
                print("Main", geometry.frame(in: .global).height)
            }
            
            return .clear
        }
    }
    
    private func calculateWidth(_ binding: Binding<CGFloat>) -> some View {
        GeometryReader { geometry -> Color in
            DispatchQueue.main.async {
                binding.wrappedValue = geometry.size.width
                print("Main", geometry.size.width)
            }
            
            return .clear
        }
    }
}

struct DynamicSearchViewModifier: ViewModifier {
    @Binding var editQuickBar: Bool
    @Binding var isSearching: Bool
    
    @ObservedObject var keyboardHeightHelper = KeyboardHeightHelper.share
    
    
    func body(content: Content) -> some View {
        content
            .modifier(DynamicSearchViewFrame(isSearching: $isSearching, editQuickBar: $editQuickBar))
            .modifier(DynamicSearchViewAnimation(editQuickBar: $editQuickBar, isSearching: $isSearching))
    }
}


struct DynamicSearchViewAnimation: ViewModifier {
    @Binding var editQuickBar: Bool
    @Binding var isSearching: Bool
    
    @ObservedObject var keyboardHeightHelper = KeyboardHeightHelper.share
    
    
    func body(content: Content) -> some View {
        content
            .animation(.spring().delay(0.6), value: self.isSearching)
            .animation(.spring(), value: self.keyboardHeightHelper.keyboardHeight)
            .padding(.horizontal, 33)
            .opacity(keyboardHeightHelper.keyboardHasShown == true ? 100 : 0)
            .animation(.spring().delay(0.5), value: keyboardHeightHelper.keyboardHasShown)
    }
}

struct DynamicSearchViewFrame: ViewModifier {
    @Binding var isSearching: Bool
    @Binding var editQuickBar: Bool
    
    @ObservedObject var keyboardHeightHelper = KeyboardHeightHelper.share
    
    func body(content: Content) -> some View {
        content
            .frame(height: isSearching ? (editQuickBar ? Screen.main.height - 69 - self.keyboardHeightHelper.maxKeyboardHeight : Screen.main.height - 69 - self.keyboardHeightHelper.keyboardHeight) : Screen.main.height - 91)
            .frame(width: Screen.main.width - 33 * 2)
    }
}

enum DragState {
    case insactive
    case pressing
    case draggging(translation: CGSize)
    
    var translation: CGSize {
        switch self {
        case .insactive:
            return .zero
        case .pressing:
            return .zero
        case .draggging(let translation):
            return translation
        }
    }
    
    var isDragging: Bool {
        switch self {
        case .insactive:
            return false
        case .pressing:
            return false
        case .draggging:
            return true
        }
    }
    
    var isPressing: Bool {
        switch self {
        case .insactive:
            return false
        case .pressing:
            return true
        case .draggging:
            return true
        }
    }
}

struct SeachView_Previews: PreviewProvider {
    static var previews: some View {
        SeachView(searchBarHeight: .constant(50), isSearching: .constant(true), editQuickBar: .constant(false), searchText: .constant(""))
    }
}
