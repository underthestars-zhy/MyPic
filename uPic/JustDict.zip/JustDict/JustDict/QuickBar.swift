//
//  QuickBar.swift
//  QuickBar
//
//  Created by 朱浩宇 on 2021/7/22.
//

import SwiftUI

struct QuickBar: View {
    @Binding var editQuickBar: Bool
    @Binding var searchText: String
    @Binding var needKeyBoard: Bool
    @Binding var isSeaching: Bool
    
    @State var showSettingView: Bool = false
    
    @ObservedObject var dataManager = DataManager.shared
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        HStack(spacing: 0) {
            Button(action: {
                showSettingView.toggle()
            }) {
                Image(systemName: "gear.circle")
                    .font(.system(size: 25, weight: .regular))
                    .foregroundColor(.blue)
            }
            .padding(.trailing, 25)
            .sheet(isPresented: $showSettingView) {
                SettingView()
            }
            
            if isSeaching {
                Text(getText())
                    .padding(.horizontal, 17)
                    .padding(.vertical, 4)
                    .foregroundColor(Color(.sRGB, red: 153 / 255, green: 153 / 255, blue: 153 / 255, opacity: 1))
                    .overlay({
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color(.sRGB, red: 153 / 255, green: 153 / 255, blue: 153 / 255, opacity: 1), lineWidth: 3)
                    })
                    .opacity(colorScheme == .light ? 0.5 : 0.8)
                    .contextMenu(menuItems: {
                        Button(action: {}) {
                            HStack {
                                Text("编辑\(getText())")
                                Spacer()
                                Image(systemName: "pencil")
                            }
                        }
                        
                        Menu {
                            ForEach(dataManager.listDataSetsUUID(), id: \.self) { uuid in
                                Button(action: {
                                    
                                }) {
                                    Text(dataManager.getDataSet(from: uuid).name ?? "Default")
                                }
                            }
                        } label: {
                            HStack {
                                Text("前往")
                                Spacer()
                                Image(systemName: "airplane.departure")
                            }
                        }

                    })
                    .onLongPressGesture(minimumDuration: 0.1) {
                        self.editQuickBar = true
                    }
            } else {
                Button(action: {
                    needKeyBoard = true
                }) {
                    Image(systemName: "keyboard")
                        .font(.title2)
                        .padding(.horizontal, 17)
                        .padding(.vertical, 4)
                        .foregroundColor(Color(.sRGB, red: 153 / 255, green: 153 / 255, blue: 153 / 255, opacity: 1))
                        .overlay({
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color(.sRGB, red: 153 / 255, green: 153 / 255, blue: 153 / 255, opacity: 1), lineWidth: 3)
                        })
                        .opacity(colorScheme == .light ? 0.5 : 0.8)
                }
            }

            
            Button(action: {
                searchText += UIPasteboard.general.string ?? ""
            }) {
                Image(systemName: "doc.on.clipboard.fill")
                    .font(.system(size: 21, weight: .regular))
                    .foregroundColor(.orange)
            }
            .padding(.leading, 25)
            
        }
    }
    
    func getText() -> String {
        return dataManager.getDataSet(from: dataManager.frontSetUUID).name ?? "Default"
    }
}

struct QuickBar_Previews: PreviewProvider {
    static var previews: some View {
        QuickBar(editQuickBar: .constant(false), searchText: .constant(""), needKeyBoard: .constant(true), isSeaching: .constant(true))
    }
}
