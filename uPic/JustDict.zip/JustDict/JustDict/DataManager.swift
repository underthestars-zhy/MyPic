//
//  DataManager.swift
//  DataManager
//
//  Created by 朱浩宇 on 2021/7/27.
//

import Foundation
import SwiftUI
import CoreData
import SwiftUIX

class DataManager: ObservableObject {
    static let shared = DataManager()
    
    let userDefaults = UserDefaults.standard
    let context = PersistenceController.shared.container.viewContext
    
    @Published var allDataSets: [DataSet]
    @Published var frontSetUUID: UUID
    
    private var hashTable = [UUID : DataSet]()
    private var allUUID = [UUID]()
    
    init() {
        allDataSets = []
        frontSetUUID = UUID()
        
        if !userDefaults.bool(forKey: "creatDefaultSet") {
            userDefaults.set(true, forKey: "creatDefaultSet")
            let defaultSet = DataSet(context: context)
            defaultSet.dictType = DictType.collins.rawValue
            defaultSet.fromLanguage = Language.zh_ch.rawValue
            defaultSet.toLanguage = Language.en.rawValue
            defaultSet.usingTimes = 0
            defaultSet.uuid = UUID()
            
            do {
                try context.save()
            } catch {
                fatalError(error.localizedDescription)
            }
            
            frontSetUUID = defaultSet.uuid ?? UUID()
            
            allDataSets.append(defaultSet)
        } else {
            let dataSetFetch = NSFetchRequest<DataSet>(entityName: "DataSet")
            
            do {
                let dataSetItems = try context.fetch(dataSetFetch)
                
                allDataSets = dataSetItems.sorted(by: { item1, item2 in
                    item1.usingTimes > item2.usingTimes
                })
                
                frontSetUUID = allDataSets.first?.uuid ?? UUID()
            } catch {
                fatalError(error.localizedDescription)
            }
        }
    }
    
    func getDataSet(from _uuid: UUID) -> DataSet {
        if let dataSet = hashTable[_uuid] {
            return dataSet
        }
        
        for dataSet in self.allDataSets {
            if dataSet.uuid == _uuid {
                hashTable[_uuid] = dataSet
                return dataSet
            }
        }
        
        fatalError("Cannot find DataSet \(_uuid)")
    }
    
    func listDataSetsUUID() -> [UUID] {
        if allUUID.count != allDataSets.count {
            allUUID = []
            for item in allDataSets {
                allUUID.append(item.uuid ?? UUID())
            }
        }
        
        return allUUID
    }
    
    func listDataSetHistoryWord(from uuid: UUID) -> [UUID] {
        let dataSet = getDataSet(from: uuid)
        var words = [Word]()
        for item in dataSet.historyWords as? Set<Word> ?? [] {
            words.append(item)
        }
        
        var wordsUUID = [UUID]()
        
        for item in words {
            wordsUUID.append(item.wordID ?? UUID())
        }
        
        return wordsUUID
    }
    
    func sortWords(words: [Word], setId: UUID) -> Word {
        return words.sorted { word1, word2 in
            
        }
    }
    
    func getWordUseingTimes(by uuid: UUID, word: Word) -> Int {
        for item in word.times as? Set<UsingTIme>
    }
}

enum DictType: Int16 {
    case collins = 0
}

enum Language: String {
    case zh_ch = "zh_cn"
    case en = "en"
}
