//
//  SettingView.swift
//  SettingView
//
//  Created by 朱浩宇 on 2021/7/25.
//

import SwiftUI
import SwiftUIX
import Introspect

struct SettingView: View {
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        Form {
            
        }
        .introspectViewController { viewController in
            viewController.view.backgroundColor = colorScheme == .light ? Color(hexadecimal: "EEEEEE").toUIColor() : Color(hexadecimal: "000000").toUIColor()
        }
    }
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}
