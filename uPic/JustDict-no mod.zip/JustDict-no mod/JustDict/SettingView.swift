//
//  SettingView.swift
//  SettingView
//
//  Created by 朱浩宇 on 2021/7/25.
//

import SwiftUI

struct SettingView: View {
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        Form {
            
        }
    }
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView()
    }
}
