//
//  ContentView.swift
//  JustDict
//
//  Created by 朱浩宇 on 2021/7/21.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContex
    @Environment(\.colorScheme) var colorScheme
    
    @State var searchText: String = ""
    @State var isSearching: Bool = true
    @State var editQuickBar: Bool = false
    @State private var searchBarHeight: CGFloat = 0
    @State var needKeyBoard: Bool = false
    
    @FocusState private var isfocusAble: Bool
    @ObservedObject var keyboardHeightHelper = KeyboardHeightHelper.share

    var body: some View {
        VStack {
            SearchBar(text: $searchText, isEditing: $isSearching)
                .onChange(of: needKeyBoard, perform: { state in
                    print(needKeyBoard)
                    if state == true {
                        isfocusAble = true
                        isSearching = true
                        searchText = ""
                        needKeyBoard = false
                    }
                })
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.isfocusAble = true
                    }
                }
                .focused($isfocusAble)
                .background(calculateHeight($searchBarHeight))
                .padding(.top, 71)
                .padding(.horizontal, 19)
            
            Spacer()
            
            QuickBar(editQuickBar: $editQuickBar, searchText: $searchText, needKeyBoard: $needKeyBoard, isSeaching: $isSearching)
                .opacity(keyboardHeightHelper.keyboardHasShown == true ? 100 : 0)
                .animation(.spring().delay(1.3), value: keyboardHeightHelper.keyboardHasShown)
                .offset(x: 0, y: editQuickBar && isSearching ? -(keyboardHeightHelper.maxKeyboardHeight + 19) :  self.keyboardHeightHelper.keyboardHeight == 0 ? -43 : -(self.keyboardHeightHelper.keyboardHeight + 19))
                .animation(.spring(), value: self.keyboardHeightHelper.keyboardHeight)
        }
        .overlay(
            SeachView(searchBarHeight: $searchBarHeight, isSearching: $isSearching, editQuickBar: $editQuickBar, searchText: $searchText)
                .ignoresSafeArea()
        )
        .ignoresSafeArea()
    }
    
    private func calculateHeight(_ binding: Binding<CGFloat>) -> some View {
        GeometryReader { geometry -> Color in
            DispatchQueue.main.async {
                binding.wrappedValue = geometry.frame(in: .global).height
            }
            
            return .clear
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

struct SearchBar: View {
    @Binding var text: String
    @Binding var isEditing: Bool
    var body: some View {
        HStack {
            TextField("Search ...", text: $text)
                .padding(7)
                .padding(.horizontal, 25)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal, 10)
                .onTapGesture {
                    self.isEditing = true
                }
            if isEditing {
                Button(action: {
                    self.isEditing = false
                    self.text = ""
                }) {
                    Text("Cancel")
                }
                .padding(.trailing, 10)
            }
        }
    }
}

struct Screen {
    static let main = Screen()
    var width: CGFloat {
        UIScreen.main.bounds.width
    }
    
    var height: CGFloat {
        UIScreen.main.bounds.height
    }
}
