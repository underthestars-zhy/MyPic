//
//  KeyBoardHelper.swift
//  KeyBoardHelper
//
//  Created by 朱浩宇 on 2021/7/22.
//

import UIKit
import SwiftUI
import Foundation

class KeyboardHeightHelper: ObservableObject {
    static let share = KeyboardHeightHelper()
    @Published var keyboardHeight: CGFloat = 0
    var maxKeyboardHeight: CGFloat = 0
    @Published var keyboardHasShown: Bool = false
    
    private func listenForKeyboardNotifications() {
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardDidShowNotification,
                                               object: nil,
                                               queue: .main) { (notification) in
            guard let userInfo = notification.userInfo,
                  let keyboardRect = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
            
            self.keyboardHeight = keyboardRect.height
            self.maxKeyboardHeight = max(self.maxKeyboardHeight, self.keyboardHeight)
            self.keyboardHasShown = self.keyboardHasShown || true
        }
        
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardDidHideNotification,
                                               object: nil,
                                               queue: .main) { (notification) in
            self.keyboardHeight = 0
        }
    }
    
    init() {
        self.listenForKeyboardNotifications()
    }
}
