//
//  QuickBar.swift
//  QuickBar
//
//  Created by 朱浩宇 on 2021/7/22.
//

import SwiftUI

struct QuickBar: View {
    @Binding var editQuickBar: Bool
    @Binding var searchText: String
    @Binding var needKeyBoard: Bool
    @Binding var isSeaching: Bool
    
    @State var showSettingView: Bool = false
    
    @ObservedObject var dataManager = DataManager.shared
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        HStack(spacing: 0) {
            Button(action: {
                showSettingView.toggle()
            }) {
                Image(systemName: "gear.circle")
                    .font(.system(size: 25, weight: .regular))
                    .foregroundColor(.blue)
            }
            .padding(.trailing, 25)
            .sheet(isPresented: $showSettingView) {
                SettingView()
            }
            
            

            
            Button(action: {
                searchText += UIPasteboard.general.string ?? ""
            }) {
                Image(systemName: "doc.on.clipboard.fill")
                    .font(.system(size: 21, weight: .regular))
                    .foregroundColor(.orange)
            }
            .padding(.leading, 25)
            
        }
    }
    
    func getText() -> String {
        return dataManager.getDataSet(from: dataManager.frontSetUUID).name ?? "Default"
    }
}

struct QuickBar_Previews: PreviewProvider {
    static var previews: some View {
        QuickBar(editQuickBar: .constant(false), searchText: .constant(""), needKeyBoard: .constant(true), isSeaching: .constant(true))
    }
}
