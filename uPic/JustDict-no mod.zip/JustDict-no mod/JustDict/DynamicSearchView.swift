//
//  DynamicSearchView.swift
//  DynamicSearchView
//
//  Created by 朱浩宇 on 2021/7/23.
//

import SwiftUI

struct DynamicSearchView: View {
    @Environment(\.colorScheme) var colorScheme
    
    @ObservedObject var keyboardHeightHelper = KeyboardHeightHelper.share
    @ObservedObject var dataManager = DataManager.shared
    
    @Binding var isSearching: Bool
    @Binding var searchText: String
    
    let setId: UUID
    
    var body: some View {
        RoundedRectangle(cornerRadius: 23)
            .foregroundColor(colorScheme == .light ? Color(.sRGB, red: 255 / 255, green: 255 / 255, blue: 255 / 255) : Color(.sRGB, red: 28 / 255, green: 27 / 255, blue: 29 / 255))
            .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 0)
            .overlay(VStack{
                if isSearching && searchText == "" {
                    ScrollView {
                        VStack {
                            Text("1")
                            Text("1")
                            Text("1")
                            Text("1")
                        }
                    }
                    .padding()
                }
            }, alignment: .center)
    }
}

